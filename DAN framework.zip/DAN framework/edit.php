<?php
defined('AUTH') or die('Restricted access');

echo '------- EDIT -------';