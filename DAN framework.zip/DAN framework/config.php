<?php
defined('AUTH') or die('Restricted access');

$domain = '';
$email = '';

$db_host = '';
$db_name = '';
$db_user = '';
$db_password = '';

