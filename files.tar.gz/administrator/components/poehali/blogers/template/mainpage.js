window.addEventListener('DOMContentLoaded', function(){
	DAN.show('poehali_blogers_photo', 'poehali_blogers_container')
});